/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright (C) 2018, Linaro Limited
 */

#ifndef __RNG_PTA_H
#define __RNG_PTA_H

void rng_collect_entropy(void);

#endif /* __RNG_PTA_H */
